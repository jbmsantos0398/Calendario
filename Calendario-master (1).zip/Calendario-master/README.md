# Calendario
## :calendar: Um calendario usando HTML, CSS e JavaScript
### Essa é uma aplicação web, utilizando web storage para armazenamento

> status: concluido ✔️

> Funcionalidades: </br>
> Dark Mode </br>
> Agendamento de evento </br>
> Deletar eventos ja existentes </br>
> Navegar pelos mêses anteriores e posteriores </br>
